import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

const timestamp = () => text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`);

export const workspaces = sqliteTable("workspaces", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp(),
});

export const subjects = sqliteTable("subjects", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull().default(""),
  fieldsJson: text("fields_json").notNull().default("[]"),
  x: integer("x").notNull().default(0),
  y: integer("y").notNull().default(0),
  createdAt: timestamp(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const connections = sqliteTable("connections", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull(),
  fromSubjectId: text("from_subject_id").notNull(),
  toSubjectId: text("to_subject_id").notNull(),
  label: text("label").notNull(),
  createdAt: timestamp(),
});

export const evidence = sqliteTable("evidence", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull(),
  subjectId: text("subject_id"),
  source: text("source").notNull(),
  objectKey: text("object_key"),
  originalName: text("original_name"),
  note: text("note").notNull().default(""),
  createdAt: timestamp(),
});

export const actions = sqliteTable("actions", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull(),
  subjectId: text("subject_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  inputJson: text("input_json").notNull().default("{}"),
  status: text("status").notNull().default("ready"),
  approvalRequired: integer("approval_required", { mode: "boolean" }).notNull().default(true),
  createdAt: timestamp(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const executions = sqliteTable("executions", {
  id: text("id").primaryKey(),
  actionId: text("action_id").notNull(),
  status: text("status").notNull(),
  attempt: integer("attempt").notNull().default(1),
  resultJson: text("result_json").notNull().default("{}"),
  error: text("error"),
  startedAt: text("started_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  completedAt: text("completed_at"),
});
