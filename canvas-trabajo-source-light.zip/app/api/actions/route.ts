const PERSONAL_WORKSPACE_ID = "personal";

async function database() {
  const { env } = await import("cloudflare:workers");
  return env.DB;
}

export async function PUT(request: Request) {
  try {
    const payload = await request.json() as { actionId?: string; decision?: "approved" | "rejected"; note?: string };
    if (!payload.actionId || !payload.decision) return Response.json({ error: "Decisión inválida." }, { status: 400 });
    const db = await database();
    if (!db) throw new Error("La base de datos no está disponible todavía.");
    const executionId = crypto.randomUUID();
    const outcome = payload.decision === "approved" ? "approved" : "rejected";
    await db.batch([
      db.prepare("UPDATE actions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND workspace_id = ?").bind(outcome, payload.actionId, PERSONAL_WORKSPACE_ID),
      db.prepare("INSERT INTO executions (id, action_id, status, attempt, result_json, completed_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)").bind(executionId, payload.actionId, "completed", 1, JSON.stringify({ decision: outcome, note: payload.note?.trim() ?? "", effect: "Decisión humana registrada; ninguna acción externa fue enviada." })),
    ]);
    return Response.json({ ok: true, executionId, status: outcome });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "No se pudo registrar la decisión." }, { status: 500 });
  }
}
