import { PERSONAL_WORKSPACE_ID, seedConnections, seedNodes } from "../../../lib/canvas-seed";
import type { CanvasSnapshot } from "../../../lib/canvas-types";

async function database() {
  const { env } = await import("cloudflare:workers");
  if (!env.DB) throw new Error("La base de datos no está disponible todavía.");
  return env.DB;
}

function parseFields(value: string): Array<[string, string]> {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function seedIfNeeded() {
  const db = await database();
  await db.prepare("INSERT OR IGNORE INTO workspaces (id, name) VALUES (?, ?)").bind(PERSONAL_WORKSPACE_ID, "Juan Diego · Personal").run();
  const existing = await db.prepare("SELECT COUNT(*) AS count FROM subjects WHERE workspace_id = ?").bind(PERSONAL_WORKSPACE_ID).first<{ count: number }>();
  if ((existing?.count ?? 0) > 0) return;

  const statements = seedNodes.map((node) => db.prepare("INSERT INTO subjects (id, workspace_id, kind, title, subtitle, fields_json, x, y) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind(node.id, PERSONAL_WORKSPACE_ID, node.kind, node.title, node.subtitle, JSON.stringify(node.fields), node.x, node.y));
  statements.push(...seedConnections.map((connection) => db.prepare("INSERT INTO connections (id, workspace_id, from_subject_id, to_subject_id, label) VALUES (?, ?, ?, ?, ?)").bind(connection.id, PERSONAL_WORKSPACE_ID, connection.from, connection.to, connection.label)));
  statements.push(db.prepare("INSERT INTO actions (id, workspace_id, subject_id, type, title, input_json, status, approval_required) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind("follow-up-bolivar", PERSONAL_WORKSPACE_ID, "aprobacion", "relationship_follow_up", "Revisar siguiente paso con Bolívar", JSON.stringify({ guardrail: "No enviar ni publicar automáticamente" }), "waiting_approval", 1));
  await db.batch(statements);
}

export async function GET() {
  try {
    await seedIfNeeded();
    const db = await database();
    const [subjectRows, connectionRows, actionRows] = await Promise.all([
      db.prepare("SELECT id, kind, title, subtitle, fields_json, x, y FROM subjects WHERE workspace_id = ? ORDER BY created_at").bind(PERSONAL_WORKSPACE_ID).all<{ id: string; kind: string; title: string; subtitle: string; fields_json: string; x: number; y: number }>(),
      db.prepare("SELECT id, from_subject_id, to_subject_id, label FROM connections WHERE workspace_id = ? ORDER BY created_at").bind(PERSONAL_WORKSPACE_ID).all<{ id: string; from_subject_id: string; to_subject_id: string; label: string }>(),
      db.prepare("SELECT id, subject_id, status FROM actions WHERE workspace_id = ?").bind(PERSONAL_WORKSPACE_ID).all<{ id: string; subject_id: string; status: string }>(),
    ]);
    const actionBySubject = new Map(actionRows.results.map((action) => [action.subject_id, action]));
    const snapshot: CanvasSnapshot = {
      nodes: subjectRows.results.map((subject) => ({ ...subject, kind: subject.kind as CanvasSnapshot["nodes"][number]["kind"], fields: parseFields(subject.fields_json), actionId: actionBySubject.get(subject.id)?.id, actionStatus: actionBySubject.get(subject.id)?.status })),
      connections: connectionRows.results.map((connection) => ({ id: connection.id, from: connection.from_subject_id, to: connection.to_subject_id, label: connection.label })),
    };
    return Response.json(snapshot);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "No se pudo cargar el Canvas." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const payload = await request.json() as { subjectId?: string; x?: number; y?: number };
    if (!payload.subjectId || typeof payload.x !== "number" || typeof payload.y !== "number") return Response.json({ error: "Movimiento inválido." }, { status: 400 });
    const db = await database();
    await db.prepare("UPDATE subjects SET x = ?, y = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND workspace_id = ?").bind(payload.x, payload.y, payload.subjectId, PERSONAL_WORKSPACE_ID).run();
    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "No se pudo guardar el movimiento." }, { status: 500 });
  }
}
