const PERSONAL_WORKSPACE_ID = "personal";

async function bindings() {
  return import("cloudflare:workers");
}

export async function POST(request: Request) {
  try {
    const { env } = await bindings();
    const db = env.DB;
    const bucket = env.BUCKET;
    if (!db || !bucket) throw new Error("El almacenamiento todavía no está disponible.");
    const form = await request.formData();
    const file = form.get("file");
    const note = String(form.get("note") ?? "").trim();
    const title = String(form.get("title") ?? "Nueva evidencia").trim() || "Nueva evidencia";
    if (!(file instanceof File)) return Response.json({ error: "Selecciona una captura o archivo." }, { status: 400 });
    const evidenceId = crypto.randomUUID();
    const subjectId = crypto.randomUUID();
    const actionId = crypto.randomUUID();
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
    const objectKey = `evidence/${evidenceId}/${safeName}`;
    await bucket.put(objectKey, file.stream(), { httpMetadata: { contentType: file.type || "application/octet-stream" } });
    await db.batch([
      db.prepare("INSERT INTO subjects (id, workspace_id, kind, title, subtitle, fields_json, x, y) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind(subjectId, PERSONAL_WORKSPACE_ID, "interaccion", title, "Evidencia capturada · pendiente de análisis", JSON.stringify([["Fuente", "Captura subida"], ["Estado", "Pendiente de análisis"], ["Nota", note || "Sin nota"]]), 1480, 510),
      db.prepare("INSERT INTO evidence (id, workspace_id, subject_id, source, object_key, original_name, note) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(evidenceId, PERSONAL_WORKSPACE_ID, subjectId, "upload", objectKey, file.name, note),
      db.prepare("INSERT INTO actions (id, workspace_id, subject_id, type, title, input_json, status, approval_required) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind(actionId, PERSONAL_WORKSPACE_ID, subjectId, "analyze_evidence", "Preparar análisis de captura", JSON.stringify({ evidenceId, note, guardrail: "No se ejecutará ningún envío externo" }), "ready", 1),
    ]);
    return Response.json({ ok: true, subjectId, actionId, evidenceId }, { status: 201 });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "No se pudo guardar la captura." }, { status: 500 });
  }
}
