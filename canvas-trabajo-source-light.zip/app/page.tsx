"use client";

import { useEffect, useMemo, useState } from "react";
import { CanvasBoard } from "./components/CanvasBoard";
import type { CanvasSnapshot } from "../lib/canvas-types";

const views = ["Canvas", "Hoy", "Inbox", "Relaciones", "Contenido"] as const;
type View = (typeof views)[number];

export default function Home() {
  const [activeView, setActiveView] = useState<View>("Canvas");
  const [query, setQuery] = useState("");
  const [showOnlyPending, setShowOnlyPending] = useState(false);
  const [snapshot, setSnapshot] = useState<CanvasSnapshot | null>(null);
  const [notice, setNotice] = useState("Cargando estado persistente…");
  const [captureOpen, setCaptureOpen] = useState(false);
  const [captureError, setCaptureError] = useState("");
  const [capturing, setCapturing] = useState(false);

  async function loadCanvas() {
    try {
      const response = await fetch("/api/canvas", { cache: "no-store" });
      if (!response.ok) throw new Error("No fue posible cargar el Canvas.");
      setSnapshot(await response.json());
      setNotice("Datos guardados en el espacio personal.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "No fue posible cargar el Canvas.");
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => { void loadCanvas(); }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const pending = useMemo(() => snapshot?.nodes.filter((node) => node.actionStatus === "waiting_approval").length ?? 0, [snapshot]);

  async function savePosition(id: string, x: number, y: number) {
    try {
      await fetch("/api/canvas", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ subjectId: id, x, y }) });
    } catch { setNotice("El nodo se movió visualmente, pero no se pudo guardar."); }
  }

  async function decide(actionId: string, decision: "approved" | "rejected") {
    try {
      const response = await fetch("/api/actions", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ actionId, decision }) });
      if (!response.ok) throw new Error("No se pudo registrar la decisión.");
      setNotice(decision === "approved" ? "Aprobación registrada. No se ejecutó ninguna acción externa." : "Rechazo registrado.");
      await loadCanvas();
    } catch (error) { setNotice(error instanceof Error ? error.message : "No se pudo registrar la decisión."); }
  }

  async function submitCapture(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCaptureError("");
    const form = new FormData(event.currentTarget);
    const file = form.get("file");
    if (!(file instanceof File) || !file.size) { setCaptureError("Selecciona una captura antes de guardar."); return; }
    setCapturing(true);
    try {
      const response = await fetch("/api/capture", { method: "POST", body: form });
      if (!response.ok) throw new Error((await response.json().catch(() => null))?.error ?? "No se pudo guardar la captura.");
      setCaptureOpen(false);
      setNotice("Captura y evidencia guardadas. La acción queda pendiente de análisis y aprobación.");
      await loadCanvas();
    } catch (error) { setCaptureError(error instanceof Error ? error.message : "No se pudo guardar la captura."); }
    finally { setCapturing(false); }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar" aria-label="Navegación principal">
        <div className="brand-lockup"><div className="brand-mark" aria-hidden="true">◌</div><div><p className="eyebrow">OPERATING SYSTEM</p><h1>Canvas de Trabajo</h1></div></div>
        <nav className="nav-list">{views.map((view) => <button key={view} className={activeView === view ? "nav-item active" : "nav-item"} onClick={() => setActiveView(view)}><span>{view === "Canvas" ? "◫" : view === "Hoy" ? "◷" : view === "Inbox" ? "↓" : view === "Relaciones" ? "◎" : "✦"}</span>{view}</button>)}</nav>
        <div className="sidebar-footer"><p>Espacio activo</p><button className="workspace-select">Juan Diego · Personal <span>⌄</span></button><small>Empresa y espacios familiares aún no se crean: requieren separación de permisos y datos.</small></div>
      </aside>
      <section className="workspace">
        <header className="topbar"><div><p className="eyebrow">{activeView === "Canvas" ? "MAPA CAUSAL" : "SISTEMA PERSONAL"}</p><h2>{activeView === "Canvas" ? "Del hecho real a la oportunidad" : activeView}</h2></div><div className="top-actions"><label className="search-box"><span>⌕</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar nodo, persona o proyecto" /></label><button className="primary-button" onClick={() => setCaptureOpen(true)}>＋ Capturar</button></div></header>
        <div className="status-strip"><div><span className="status-dot" /><strong>Espacio personal</strong><span>{notice}</span></div><button className={showOnlyPending ? "filter-toggle selected" : "filter-toggle"} onClick={() => setShowOnlyPending(!showOnlyPending)}>{showOnlyPending ? "Mostrando pendientes" : `${pending} aprobaciones pendientes`}</button></div>
        {activeView === "Canvas" && snapshot ? <CanvasBoard key={snapshot.nodes.map((node) => `${node.id}:${node.actionStatus ?? ""}`).join("|")} query={query} showOnlyPending={showOnlyPending} nodes={snapshot.nodes} connections={snapshot.connections} onPositionCommit={savePosition} onDecision={decide} /> : <section className="coming-view"><p className="eyebrow">{activeView === "Canvas" ? "CARGANDO" : "MÓDULO EN PREPARACIÓN"}</p><h3>{activeView === "Canvas" ? "Leyendo el estado persistente…" : `${activeView} todavía no existe como módulo operacional.`}</h3><p>{activeView === "Canvas" ? "El lienzo aparecerá cuando la base de datos responda." : "No mostramos tareas ficticias. Este espacio se habilitará cuando tenga entidades y acciones reales."}</p></section>}
      </section>
      {captureOpen && <div className="modal-backdrop" role="presentation"><form className="capture-modal" onSubmit={submitCapture}><button type="button" className="modal-close" onClick={() => setCaptureOpen(false)}>×</button><p className="eyebrow">EVIDENCIA</p><h3>Guardar una captura real</h3><p>Se almacenará como evidencia y creará una acción interna pendiente. No analiza ni publica nada por sí sola.</p><label>Título<input name="title" required placeholder="Ej. Post de una persona potencial" /></label><label>Nota opcional<textarea name="note" rows={3} placeholder="Qué quieres recordar o evaluar" /></label><label>Captura<input name="file" type="file" accept="image/*" required /></label>{captureError && <p className="form-error">{captureError}</p>}<button className="primary-button" disabled={capturing}>{capturing ? "Guardando…" : "Guardar evidencia"}</button></form></div>}
    </main>
  );
}
