"use client";

import { useMemo, useRef, useState, type CSSProperties, type PointerEvent } from "react";
import type { CanvasConnection, CanvasNode, NodeKind } from "../../lib/canvas-types";

type CanvasBoardProps = {
  query?: string;
  showOnlyPending?: boolean;
  nodes: CanvasNode[];
  connections: CanvasConnection[];
  onPositionCommit: (id: string, x: number, y: number) => void;
  onDecision: (actionId: string, decision: "approved" | "rejected") => void;
};

const NODE_META: Record<NodeKind, { label: string; color: string; tint: string }> = {
  persona: { label: "Persona", color: "#4466ef", tint: "#eef1ff" },
  interaccion: { label: "Interacción", color: "#e06f2f", tint: "#fff1e8" },
  evento: { label: "Evento", color: "#9b57d5", tint: "#f6edff" },
  proyecto: { label: "Proyecto", color: "#168267", tint: "#e8f8f3" },
  contenido: { label: "Contenido", color: "#d38b18", tint: "#fff7df" },
  aprobacion: { label: "Aprobación", color: "#bf3d55", tint: "#fff0f3" },
  workflow: { label: "Workflow", color: "#1a7fa8", tint: "#eaf8ff" },
};

const BOARD_WIDTH = 1840;
const BOARD_HEIGHT = 760;

export function CanvasBoard({ query = "", showOnlyPending = false, nodes: sourceNodes, connections, onPositionCommit, onDecision }: CanvasBoardProps) {
  const [nodes, setNodes] = useState(sourceNodes);
  const [scale, setScale] = useState(0.72);
  const [offset, setOffset] = useState({ x: 8, y: 8 });
  const [activeId, setActiveId] = useState<string | null>(null);
  const panRef = useRef<{ startX: number; startY: number; x: number; y: number } | null>(null);
  const dragRef = useRef<{ id: string; startX: number; startY: number; x: number; y: number } | null>(null);

  const nodeIndex = useMemo(
    () => new Map(nodes.map((node) => [node.id, node])),
    [nodes],
  );

  const visibleNodes = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    return nodes.filter((node) => {
      if (showOnlyPending && node.kind !== "aprobacion") return false;
      if (!normalizedQuery) return true;
      const searchable = [node.title, node.subtitle, NODE_META[node.kind].label, ...node.fields.flat()]
        .join(" ")
        .toLocaleLowerCase();
      return searchable.includes(normalizedQuery);
    });
  }, [nodes, query, showOnlyPending]);

  const visibleNodeIds = useMemo(() => new Set(visibleNodes.map((node) => node.id)), [visibleNodes]);

  const zoomIn = () => setScale((current) => Math.min(1.18, +(current + 0.1).toFixed(2)));
  const zoomOut = () => setScale((current) => Math.max(0.45, +(current - 0.1).toFixed(2)));

  function resetView() {
    setScale(0.72);
    setOffset({ x: 8, y: 8 });
    setActiveId(null);
  }

  function onBoardPointerDown(event: PointerEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget) return;
    panRef.current = {
      startX: event.clientX,
      startY: event.clientY,
      x: offset.x,
      y: offset.y,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
    setActiveId(null);
  }

  function onNodePointerDown(event: PointerEvent<HTMLElement>, node: CanvasNode) {
    event.stopPropagation();
    dragRef.current = {
      id: node.id,
      startX: event.clientX,
      startY: event.clientY,
      x: node.x,
      y: node.y,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
    setActiveId(node.id);
  }

  function onPointerMove(event: PointerEvent<HTMLDivElement>) {
    if (dragRef.current) {
      const drag = dragRef.current;
      const x = Math.max(20, Math.min(BOARD_WIDTH - 280, drag.x + (event.clientX - drag.startX) / scale));
      const y = Math.max(20, Math.min(BOARD_HEIGHT - 180, drag.y + (event.clientY - drag.startY) / scale));
      setNodes((current) => current.map((node) => (node.id === drag.id ? { ...node, x, y } : node)));
      return;
    }

    if (panRef.current) {
      const pan = panRef.current;
      setOffset({ x: pan.x + event.clientX - pan.startX, y: pan.y + event.clientY - pan.startY });
    }
  }

  function endPointerInteraction() {
    const completedDrag = dragRef.current;
    if (completedDrag) {
      const node = nodes.find((item) => item.id === completedDrag.id);
      if (node) onPositionCommit(node.id, Math.round(node.x), Math.round(node.y));
    }
    dragRef.current = null;
    panRef.current = null;
  }

  return (
    <section style={styles.shell} aria-label="Canvas de trabajo">
      <header style={styles.header}>
        <div>
          <p style={styles.eyebrow}>Canvas de trabajo</p>
          <h2 style={styles.heading}>Mapa de relaciones y decisiones</h2>
          <p style={styles.description}>
            Arrastra nodos, mueve el lienzo y revisa cómo una interacción se conecta con proyectos, contenido y decisiones.
          </p>
        </div>
        <div style={styles.legend} aria-label="Leyenda de tipos de nodo">
          {Object.entries(NODE_META).map(([kind, meta]) => (
            <span key={kind} style={{ ...styles.legendItem, background: meta.tint, color: meta.color }}>
              <span style={{ ...styles.legendDot, background: meta.color }} />
              {meta.label}
            </span>
          ))}
        </div>
      </header>

      <div
        style={styles.viewport}
        onPointerDown={onBoardPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endPointerInteraction}
        onPointerCancel={endPointerInteraction}
      >
        <div style={{ ...styles.stage, transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})` }}>
          <svg width={BOARD_WIDTH} height={BOARD_HEIGHT} style={styles.connections} aria-hidden="true">
            <defs>
              <marker id="canvas-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#9aa3b7" />
              </marker>
            </defs>
            {connections.filter((connection) => visibleNodeIds.has(connection.from) && visibleNodeIds.has(connection.to)).map((connection) => {
              const from = nodeIndex.get(connection.from);
              const to = nodeIndex.get(connection.to);
              if (!from || !to) return null;
              const fromWidth = from.width ?? 270;
              const x1 = from.x + fromWidth;
              const y1 = from.y + 94;
              const x2 = to.x;
              const y2 = to.y + 94;
              const curve = Math.max(55, Math.abs(x2 - x1) * 0.38);
              const labelX = (x1 + x2) / 2;
              const labelY = (y1 + y2) / 2 - 13;
              return (
                <g key={connection.id}>
                  <path
                    d={`M ${x1} ${y1} C ${x1 + curve} ${y1}, ${x2 - curve} ${y2}, ${x2} ${y2}`}
                    fill="none"
                    stroke="#9aa3b7"
                    strokeWidth="2"
                    strokeDasharray="5 6"
                    markerEnd="url(#canvas-arrow)"
                  />
                  <rect x={labelX - 30} y={labelY - 11} width="60" height="22" rx="11" fill="#f7f8fc" stroke="#dfe3ee" />
                  <text x={labelX} y={labelY + 4} textAnchor="middle" fill="#667085" fontSize="11" fontWeight="700">
                    {connection.label}
                  </text>
                </g>
              );
            })}
          </svg>

          {visibleNodes.map((node) => {
            const meta = NODE_META[node.kind];
            const selected = activeId === node.id;
            return (
              <article
                key={node.id}
                role="button"
                tabIndex={0}
                onPointerDown={(event) => onNodePointerDown(event, node)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") setActiveId(node.id);
                }}
                style={{
                  ...styles.node,
                  width: node.width ?? 270,
                  left: node.x,
                  top: node.y,
                  borderColor: selected ? meta.color : "#dfe3ee",
                  boxShadow: selected ? `0 0 0 3px ${meta.tint}, 0 16px 40px rgba(34, 43, 73, .16)` : "0 12px 28px rgba(34, 43, 73, .10)",
                }}
                aria-label={`${meta.label}: ${node.title}`}
              >
                <div style={{ ...styles.nodeStripe, background: meta.color }} />
                <div style={styles.nodeBody}>
                  <div style={styles.nodeTopline}>
                    <span style={{ ...styles.typePill, background: meta.tint, color: meta.color }}>{meta.label}</span>
                    <span style={{ ...styles.statusDot, background: meta.color }} aria-hidden="true" />
                  </div>
                  <h3 style={styles.nodeTitle}>{node.title}</h3>
                  <p style={styles.nodeSubtitle}>{node.subtitle}</p>
                  <dl style={styles.fieldList}>
                    {node.fields.map(([label, value]) => (
                      <div key={label} style={styles.field}>
                        <dt style={styles.fieldLabel}>{label}</dt>
                        <dd style={styles.fieldValue}>{value}</dd>
                      </div>
                    ))}
                  </dl>
                  {node.actionId && node.actionStatus === "waiting_approval" && (
                    <div style={styles.decisionRow} onPointerDown={(event) => event.stopPropagation()}>
                      <button type="button" style={styles.rejectButton} onClick={() => onDecision(node.actionId!, "rejected")}>Rechazar</button>
                      <button type="button" style={styles.approveButton} onClick={() => onDecision(node.actionId!, "approved")}>Aprobar</button>
                    </div>
                  )}
                  {node.actionId && node.actionStatus && node.actionStatus !== "waiting_approval" && (
                    <p style={styles.actionState}>Registro interno: {node.actionStatus}</p>
                  )}
                </div>
              </article>
            );
          })}
        </div>

        <div style={styles.controls} aria-label="Controles del canvas">
          <button type="button" onClick={zoomOut} style={styles.controlButton} aria-label="Alejar">−</button>
          <button type="button" onClick={resetView} style={{ ...styles.controlButton, ...styles.resetButton }}>Reset</button>
          <button type="button" onClick={zoomIn} style={styles.controlButton} aria-label="Acercar">+</button>
          <span style={styles.zoomBadge}>{Math.round(scale * 100)}%</span>
        </div>
        <p style={styles.hint}>Arrastra los nodos · Las posiciones, capturas y decisiones se guardan · Ninguna acción externa se ejecuta sola.</p>
      </div>
    </section>
  );
}

export default CanvasBoard;

const styles: Record<string, CSSProperties> = {
  shell: {
    width: "100%",
    border: "1px solid #e3e6ee",
    borderRadius: 24,
    overflow: "hidden",
    background: "#ffffff",
    color: "#171a26",
    fontFamily: "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
  header: {
    display: "flex",
    gap: 24,
    justifyContent: "space-between",
    alignItems: "flex-start",
    padding: "24px clamp(18px, 3vw, 34px)",
    borderBottom: "1px solid #e9ebf0",
    background: "linear-gradient(135deg, #fcfcff 0%, #f7f9ff 100%)",
  },
  eyebrow: { margin: 0, color: "#667085", fontSize: 11, fontWeight: 800, letterSpacing: ".14em", textTransform: "uppercase" },
  heading: { margin: "7px 0 5px", fontSize: "clamp(20px, 3vw, 30px)", letterSpacing: "-.035em", lineHeight: 1.1 },
  description: { margin: 0, maxWidth: 600, color: "#667085", fontSize: 14, lineHeight: 1.55 },
  legend: { display: "flex", gap: 7, flexWrap: "wrap", justifyContent: "flex-end", maxWidth: 420, paddingTop: 2 },
  legendItem: { display: "inline-flex", alignItems: "center", gap: 6, borderRadius: 999, padding: "6px 9px", fontSize: 11, fontWeight: 750, whiteSpace: "nowrap" },
  legendDot: { width: 7, height: 7, borderRadius: "50%" },
  viewport: {
    position: "relative",
    height: "min(68vh, 720px)",
    minHeight: 510,
    overflow: "hidden",
    touchAction: "none",
    cursor: "grab",
    backgroundColor: "#fafbff",
    backgroundImage: "radial-gradient(#d7ddea 1.2px, transparent 1.2px)",
    backgroundSize: "21px 21px",
  },
  stage: { position: "absolute", width: BOARD_WIDTH, height: BOARD_HEIGHT, transformOrigin: "0 0", transition: "transform 120ms ease-out" },
  connections: { position: "absolute", inset: 0, overflow: "visible", pointerEvents: "none" },
  node: { position: "absolute", minHeight: 190, border: "1px solid", borderRadius: 17, background: "rgba(255,255,255,.98)", overflow: "hidden", cursor: "grab", userSelect: "none", touchAction: "none", transition: "box-shadow 160ms ease, border-color 160ms ease" },
  nodeStripe: { height: 4, width: "100%" },
  nodeBody: { padding: "13px 15px 15px" },
  nodeTopline: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 9 },
  typePill: { display: "inline-flex", padding: "4px 7px", borderRadius: 7, fontSize: 10, fontWeight: 800, letterSpacing: ".02em" },
  statusDot: { width: 8, height: 8, borderRadius: "50%" },
  nodeTitle: { margin: 0, fontSize: 15, letterSpacing: "-.02em", lineHeight: 1.2 },
  nodeSubtitle: { margin: "5px 0 12px", color: "#667085", fontSize: 11.5, lineHeight: 1.35 },
  fieldList: { display: "grid", gap: 7, margin: 0 },
  field: { display: "grid", gridTemplateColumns: "77px 1fr", gap: 6, alignItems: "start" },
  fieldLabel: { color: "#8b94a7", fontSize: 10.5, fontWeight: 700 },
  fieldValue: { margin: 0, color: "#344054", fontSize: 10.5, fontWeight: 650, lineHeight: 1.35 },
  decisionRow: { display: "flex", gap: 7, marginTop: 14 },
  approveButton: { flex: 1, border: 0, borderRadius: 8, padding: "8px 9px", background: "#2f42de", color: "#fff", fontSize: 10.5, fontWeight: 800, cursor: "pointer" },
  rejectButton: { flex: 1, border: "1px solid #e2c1c9", borderRadius: 8, padding: "8px 9px", background: "#fff", color: "#9b3147", fontSize: 10.5, fontWeight: 800, cursor: "pointer" },
  actionState: { margin: "13px 0 0", color: "#536078", fontSize: 10.5, fontWeight: 750 },
  controls: { position: "absolute", right: 16, bottom: 42, display: "flex", alignItems: "center", gap: 7, padding: 7, border: "1px solid #e1e5ee", borderRadius: 15, background: "rgba(255,255,255,.95)", boxShadow: "0 10px 24px rgba(34,43,73,.10)" },
  controlButton: { width: 34, height: 34, border: "1px solid #e0e4ed", borderRadius: 9, color: "#283044", background: "#fff", fontSize: 19, fontWeight: 700, cursor: "pointer" },
  resetButton: { width: "auto", padding: "0 10px", fontSize: 11 },
  zoomBadge: { minWidth: 46, color: "#4661a5", background: "#edf2ff", padding: "9px 8px", borderRadius: 9, fontSize: 11, fontWeight: 800, textAlign: "center" },
  hint: { position: "absolute", left: 16, bottom: 12, margin: 0, color: "#7b8498", fontSize: 11, background: "rgba(250,251,255,.84)", padding: "5px 7px", borderRadius: 7 },
};
