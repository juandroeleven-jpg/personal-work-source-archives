export type NodeKind =
  | "persona"
  | "interaccion"
  | "evento"
  | "proyecto"
  | "contenido"
  | "aprobacion"
  | "workflow";

export type CanvasNode = {
  id: string;
  kind: NodeKind;
  title: string;
  subtitle: string;
  fields: Array<[string, string]>;
  x: number;
  y: number;
  width?: number;
  actionId?: string;
  actionStatus?: string;
};

export type CanvasConnection = { id: string; from: string; to: string; label: string };

export type CanvasSnapshot = {
  nodes: CanvasNode[];
  connections: CanvasConnection[];
};
