import type { CanvasConnection, CanvasNode } from "./canvas-types";

export const PERSONAL_WORKSPACE_ID = "personal";

export const seedNodes: CanvasNode[] = [
  { id: "bolivar", kind: "persona", title: "Bolívar Domínguez G.", subtitle: "Vice President, Flight Operations · Copa Airlines", fields: [["Relación", "Conversación abierta"], ["Actividad", "Activa en LinkedIn"], ["Próximo paso", "Aportar valor; no vender aún"]], x: 80, y: 135 },
  { id: "interaccion", kind: "interaccion", title: "Interacción de LinkedIn", subtitle: "Comentario + respuesta positiva", fields: [["Fecha", "23 ago 2026"], ["Resultado", "Conexión aceptada"], ["Señal", "Reciprocidad alta"]], x: 410, y: 55 },
  { id: "evento", kind: "evento", title: "Foro de innovación", subtitle: "Evento profesional · Panamá", fields: [["Objetivo", "Aprender + 3 contactos"], ["Aprendizaje", "IA, disciplina y operaciones"], ["Evidencia", "Notas y fotografías"]], x: 430, y: 388 },
  { id: "proyecto", kind: "proyecto", title: "Sistema de trabajo Canvas", subtitle: "Proyecto personal · En diseño", fields: [["Objetivo", "Ordenar trabajo, marca y relaciones"], ["Estado", "Persistencia en construcción"], ["Espacio", "Personal"]], x: 770, y: 215 },
  { id: "contenido", kind: "contenido", title: "Idea: IA y trazabilidad", subtitle: "Video vertical · Pilar IA aplicada", fields: [["Tesis", "Automatizar sin perder criterio"], ["Origen", "Proyecto + evento"], ["Estado", "Guion pendiente"]], x: 1110, y: 70 },
  { id: "aprobacion", kind: "aprobacion", title: "Aprobar siguiente acción", subtitle: "Decisión humana requerida", fields: [["Propuesta", "Comentar / guardar / esperar"], ["Riesgo", "Reputación y relación"], ["Estado", "Pendiente"]], x: 1110, y: 400, actionId: "follow-up-bolivar", actionStatus: "waiting_approval" },
  { id: "workflow", kind: "workflow", title: "Clasificar screenshot", subtitle: "Captura → acción pendiente de análisis", fields: [["Entrada", "Screenshot + nota opcional"], ["Salida", "Perfil y siguiente paso"], ["Acción externa", "Nunca automática"]], x: 1460, y: 230 },
];

export const seedConnections: CanvasConnection[] = [
  { id: "c1", from: "bolivar", to: "interaccion", label: "genera" },
  { id: "c2", from: "evento", to: "proyecto", label: "informa" },
  { id: "c3", from: "interaccion", to: "aprobacion", label: "requiere" },
  { id: "c4", from: "proyecto", to: "contenido", label: "origina" },
  { id: "c5", from: "contenido", to: "aprobacion", label: "espera" },
  { id: "c6", from: "aprobacion", to: "workflow", label: "autoriza" },
];
