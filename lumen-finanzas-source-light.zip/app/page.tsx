"use client";

import Image from "next/image";
import { FormEvent, useEffect, useMemo, useState } from "react";

type Category = "Comida" | "Transporte" | "Compras" | "Suscripciones" | "Hogar" | "Transferencias" | "Ingresos" | "Cargos";
type Transaction = { id: string; date: string; merchant: string; amount: number; category: Category; source: string };

const initialTransactions: Transaction[] = [
  { id: "1", date: "2026-08-15", merchant: "Yappy a Virginia", amount: -2, category: "Transferencias", source: "Cuenta" },
  { id: "2", date: "2026-08-15", merchant: "Yappy a Eduardo", amount: -2, category: "Transferencias", source: "Cuenta" },
  { id: "3", date: "2026-08-15", merchant: "Notion", amount: -12, category: "Suscripciones", source: "Cuenta" },
  { id: "4", date: "2026-08-15", merchant: "Uber Rides", amount: -4.38, category: "Transporte", source: "Tarjeta débito" },
  { id: "5", date: "2026-08-16", merchant: "Yappy de María F.", amount: 13, category: "Ingresos", source: "Cuenta" },
  { id: "6", date: "2026-08-17", merchant: "Uber Rides", amount: -2.72, category: "Transporte", source: "Cuenta" },
  { id: "7", date: "2026-08-17", merchant: "Uber Rides", amount: -3.16, category: "Transporte", source: "Cuenta" },
  { id: "8", date: "2026-08-18", merchant: "Yappy de María F.", amount: 3.78, category: "Ingresos", source: "Cuenta" },
  { id: "9", date: "2026-08-18", merchant: "Maissi Beauty Shop", amount: -26.97, category: "Compras", source: "Cuenta" },
  { id: "10", date: "2026-08-18", merchant: "Terpel Calle", amount: -1.2, category: "Transporte", source: "Cuenta" },
  { id: "11", date: "2026-08-18", merchant: "Riba Smith Costa del Este", amount: -2.36, category: "Comida", source: "Cuenta" },
  { id: "12", date: "2026-08-18", merchant: "Riba Smith Vía Transístmica", amount: -13.63, category: "Comida", source: "Cuenta" },
  { id: "13", date: "2026-08-18", merchant: "Uber Rides", amount: -5.12, category: "Transporte", source: "Cuenta" },
  { id: "14", date: "2026-08-18", merchant: "Uber Rides", amount: -4.06, category: "Transporte", source: "Cuenta" },
  { id: "15", date: "2026-08-18", merchant: "Pan y Canela Café", amount: -5.2, category: "Comida", source: "Cuenta" },
  { id: "16", date: "2026-08-18", merchant: "Uber Rides", amount: -5.14, category: "Transporte", source: "Cuenta" },
  { id: "17", date: "2026-08-18", merchant: "Uber Rides", amount: -2.97, category: "Transporte", source: "Cuenta" },
  { id: "18", date: "2026-08-18", merchant: "PP14 Santa Ana", amount: -2.25, category: "Transporte", source: "Cuenta" },
  { id: "19", date: "2026-08-18", merchant: "Uber Rides", amount: -4.93, category: "Transporte", source: "Cuenta" },
  { id: "20", date: "2026-08-19", merchant: "Uber One Membership", amount: -5.99, category: "Suscripciones", source: "Cuenta" },
  { id: "21", date: "2026-08-19", merchant: "Estación Texaco", amount: -20, category: "Transporte", source: "Cuenta" },
  { id: "22", date: "2026-08-19", merchant: "Est. Multiplaza", amount: -4, category: "Transporte", source: "Cuenta" },
  { id: "23", date: "2026-08-19", merchant: "Riba Smith Vía Transístmica", amount: -3.12, category: "Comida", source: "Cuenta" },
  { id: "24", date: "2026-08-20", merchant: "PedidosYa Greek House", amount: -12.83, category: "Comida", source: "Cuenta" },
  { id: "25", date: "2026-08-20", merchant: "Mini Market JC Bella Vista", amount: -2.75, category: "Comida", source: "Tarjeta débito" },
  { id: "26", date: "2026-08-20", merchant: "Uber Rides", amount: -4.12, category: "Transporte", source: "Tarjeta débito" },
  { id: "27", date: "2026-08-20", merchant: "Cinemark Pacific Center", amount: -10, category: "Compras", source: "Tarjeta débito" },
  { id: "28", date: "2026-08-20", merchant: "Premium Food Pacific", amount: -3.24, category: "Comida", source: "Tarjeta débito" },
  { id: "29", date: "2026-08-20", merchant: "Meshy", amount: -20.8, category: "Suscripciones", source: "Tarjeta débito" },
  { id: "30", date: "2026-08-17", merchant: "Financiamiento Visa", amount: -15.97, category: "Cargos", source: "Visa" },
  { id: "31", date: "2026-08-17", merchant: "Seguro de desgravamen", amount: -0.59, category: "Cargos", source: "Visa" },
  { id: "32", date: "2026-08-17", merchant: "ITBMS cargo por seguro", amount: -0.03, category: "Cargos", source: "Visa" },
  { id: "33", date: "2026-08-17", merchant: "ITBMS cargo por seguro", amount: -0.18, category: "Cargos", source: "Visa" },
  { id: "34", date: "2026-08-17", merchant: "Seguro de fraude mensual", amount: -3.5, category: "Cargos", source: "Visa" },
];

const categories: Category[] = ["Comida", "Transporte", "Compras", "Suscripciones", "Hogar", "Transferencias", "Ingresos", "Cargos"];
const money = new Intl.NumberFormat("es-PA", { style: "currency", currency: "USD" });
const dateFormatter = new Intl.DateTimeFormat("es-PA", { day: "numeric", month: "short" });
const icons: Record<Category, string> = { Comida: "✦", Transporte: "↗", Compras: "◇", Suscripciones: "∞", Hogar: "⌂", Transferencias: "⇄", Ingresos: "↓", Cargos: "!" };

const evidence: Record<string, { file: string; label: string }> = {
  "1": { file: "tx-1.webp", label: "Yappy a Virginia · 15 ago" }, "2": { file: "tx-2.webp", label: "Yappy a Eduardo · 15 ago" }, "3": { file: "tx-3.webp", label: "Notion · 15 ago" }, "4": { file: "tx-4.webp", label: "DLC Uber Rides · 15 ago" }, "5": { file: "tx-5.webp", label: "Yappy de María F. · 16 ago" }, "6": { file: "tx-6.webp", label: "Uber Rides · 17 ago" }, "7": { file: "tx-7.webp", label: "Uber Rides · 17 ago" }, "8": { file: "tx-8.webp", label: "Yappy de María F. · 18 ago" }, "9": { file: "tx-9.webp", label: "Maissi Beauty Shop · 18 ago" }, "10": { file: "tx-10.webp", label: "Terpel Calle · 18 ago" }, "11": { file: "tx-11.webp", label: "Riba Smith Costa del Este · 18 ago" }, "12": { file: "tx-12.webp", label: "Riba Smith Vía Transístmica · 18 ago" }, "13": { file: "tx-13.webp", label: "Uber Rides · 18 ago" }, "14": { file: "tx-14.webp", label: "Uber Rides · 18 ago" }, "15": { file: "tx-15.webp", label: "Pan y Canela Café · 18 ago" }, "16": { file: "tx-16.webp", label: "Uber Rides · 18 ago" }, "17": { file: "tx-17.webp", label: "Uber Rides · 18 ago" }, "18": { file: "tx-18.webp", label: "PP14 Santa Ana · 18 ago" }, "19": { file: "tx-19.webp", label: "Uber Rides · 18 ago" }, "20": { file: "tx-20.webp", label: "Uber One Membership · 19 ago" }, "21": { file: "tx-21.webp", label: "Estación Texaco · 19 ago" }, "22": { file: "tx-22.webp", label: "Est. Multiplaza · 19 ago" }, "23": { file: "tx-23.webp", label: "Riba Smith Vía Transístmica · 19 ago" }, "24": { file: "tx-24.webp", label: "PedidosYa Greek House · 20 ago" }, "25": { file: "tx-25.webp", label: "Mini Market JC Bella Vista · 20 ago" }, "26": { file: "tx-26.webp", label: "DLC Uber Rides · 20 ago" }, "27": { file: "tx-27.webp", label: "Cinemark Pacific Center · 20 ago" }, "28": { file: "tx-28.webp", label: "Premium Food Pacific · 20 ago" }, "29": { file: "tx-29.webp", label: "Meshy · 20 ago" }, "30": { file: "tx-30.webp", label: "Financiamiento Visa · 17 ago" }, "31": { file: "tx-31.webp", label: "Seguro de desgravamen · 17 ago" }, "32": { file: "tx-32.webp", label: "ITBMS cargo por seguro · 17 ago" }, "33": { file: "tx-33.webp", label: "ITBMS cargo por seguro · 17 ago" }, "34": { file: "tx-34.webp", label: "Seguro de fraude mensual · 17 ago" },
};

function formatDay(date: string) { return dateFormatter.format(new Date(`${date}T12:00:00`)).replace(".", ""); }

export default function Dashboard() {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [filter, setFilter] = useState<Category | "Todo">("Todo");
  const [modal, setModal] = useState(false);
  const [selectedEvidence, setSelectedEvidence] = useState<string | null>(null);
  const [form, setForm] = useState({ merchant: "", amount: "", category: "Comida" as Category, date: "2026-08-20", source: "Manual" });

  useEffect(() => {
    const saved = localStorage.getItem("lumen-transactions");
    if (saved) setTransactions(JSON.parse(saved));
  }, []);
  useEffect(() => localStorage.setItem("lumen-transactions", JSON.stringify(transactions)), [transactions]);

  const stats = useMemo(() => {
    const income = transactions.filter(t => t.amount > 0).reduce((s, t) => s + t.amount, 0);
    const spending = Math.abs(transactions.filter(t => t.amount < 0).reduce((s, t) => s + t.amount, 0));
    const byCategory = categories.filter(c => c !== "Ingresos").map(category => ({ category, amount: Math.abs(transactions.filter(t => t.category === category && t.amount < 0).reduce((s, t) => s + t.amount, 0)) })).filter(x => x.amount > 0).sort((a, b) => b.amount - a.amount);
    return { income, spending, balance: income - spending, byCategory };
  }, [transactions]);

  const visible = [...transactions].filter(t => filter === "Todo" || t.category === filter).sort((a, b) => b.date.localeCompare(a.date));
  const maximum = Math.max(...stats.byCategory.map(x => x.amount), 1);

  function addTransaction(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const numeric = Number(form.amount.replace(",", "."));
    if (!form.merchant || !numeric) return;
    const amount = form.category === "Ingresos" ? Math.abs(numeric) : -Math.abs(numeric);
    setTransactions(items => [{ id: crypto.randomUUID(), ...form, amount }, ...items]);
    setModal(false);
    setForm({ merchant: "", amount: "", category: "Comida", date: "2026-08-20", source: "Manual" });
  }

  return (
    <main>
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <div className="brand"><span className="brand-mark">L</span><span>LUMEN</span><small>FINANZAS</small></div>
        <div className="period"><span className="pulse" />15 — 20 AGO · 2026</div>
        <button className="profile" aria-label="Perfil">JD</button>
      </header>

      <section className="hero">
        <div><p className="eyebrow">PANORAMA FINANCIERO</p><h1>Tu dinero,<br /><em>en perspectiva.</em></h1><p className="subhead">Movimientos registrados desde el 15 de agosto.</p></div>
        <div className="hero-orbit" aria-hidden="true"><div className="orbit-ring" /><div className="orb orb-main"><span>FLUJO</span></div><div className="orb orb-small" /><div className="spark" /></div>
      </section>

      <section className="metrics">
        <article className="metric balance-card"><div className="metric-label">BALANCE DEL PERIODO <span>↗</span></div><strong className={stats.balance >= 0 ? "positive" : "negative"}>{money.format(stats.balance)}</strong><p>Ingresos menos gastos registrados</p><div className="mini-bars"><i /><i /><i /><i /><i /><i /></div></article>
        <article className="metric"><div className="metric-label">INGRESOS <span className="positive">↓</span></div><strong>{money.format(stats.income)}</strong><p>{transactions.filter(t => t.amount > 0).length} movimientos recibidos</p><div className="cube income-cube" /></article>
        <article className="metric"><div className="metric-label">GASTOS <span className="negative">↑</span></div><strong>{money.format(stats.spending)}</strong><p>{transactions.filter(t => t.amount < 0).length} movimientos registrados</p><div className="cube expense-cube" /></article>
        <article className="metric credit-card"><div className="metric-label">VISA · USO ACTUAL</div><strong>$306.44</strong><p>de $1,600.00 disponible</p><div className="credit-track"><span style={{ width: "19%" }} /></div></article>
      </section>

      <section className="grid">
        <article className="panel spending-panel"><div className="panel-heading"><div><p className="eyebrow">DISTRIBUCIÓN</p><h2>¿En qué se fue?</h2></div><span className="chip">Gastos</span></div><div className="donut-row"><div className="donut" style={{ background: `conic-gradient(#68e4ff 0 ${(stats.byCategory[0]?.amount ?? 0) / stats.spending * 360}deg, #3279ff ${(stats.byCategory[0]?.amount ?? 0) / stats.spending * 360}deg ${((stats.byCategory[0]?.amount ?? 0) + (stats.byCategory[1]?.amount ?? 0)) / stats.spending * 360}deg, #816cff ${((stats.byCategory[0]?.amount ?? 0) + (stats.byCategory[1]?.amount ?? 0)) / stats.spending * 360}deg 360deg)` }}><div><b>{money.format(stats.spending)}</b><small>Total</small></div></div><div className="legend">{stats.byCategory.slice(0, 4).map((item, i) => <div key={item.category}><i className={`dot d${i}`} /><span>{item.category}</span><b>{money.format(item.amount)}</b></div>)}</div></div></article>
        <article className="panel velocity"><div className="panel-heading"><div><p className="eyebrow">RITMO DIARIO</p><h2>Salida de dinero</h2></div><span className="trend">−14% <small>vs. ayer</small></span></div><div className="chart"><svg viewBox="0 0 600 190" preserveAspectRatio="none" aria-label="Gráfica de gasto diario"><defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#39dff9" stopOpacity=".36"/><stop offset="100%" stopColor="#39dff9" stopOpacity="0"/></linearGradient></defs><path d="M0,174 L0,145 C45,143 58,140 94,143 S145,115 184,121 S244,143 285,80 S340,116 382,90 S440,120 477,37 S543,108 600,22 L600,190 L0,190Z" fill="url(#area)"/><path d="M0,145 C45,143 58,140 94,143 S145,115 184,121 S244,143 285,80 S340,116 382,90 S440,120 477,37 S543,108 600,22" fill="none" stroke="#62e9ff" strokeWidth="3"/><circle cx="477" cy="37" r="6" fill="#0c1120" stroke="#fff" strokeWidth="2"/></svg><div className="axis"><span>15 AGO</span><span>16</span><span>17</span><span>18</span><span>19</span><span>20 AGO</span></div></div></article>
      </section>

      <section className="lower-grid">
        <article className="panel categories"><div className="panel-heading"><div><p className="eyebrow">CATEGORÍAS</p><h2>Gastos destacados</h2></div></div>{stats.byCategory.slice(0, 5).map((item, i) => <div className="category" key={item.category}><span className={`category-icon ci${i}`}>{icons[item.category]}</span><div className="category-body"><div><b>{item.category}</b><strong>{money.format(item.amount)}</strong></div><div className="bar"><i style={{ width: `${item.amount / maximum * 100}%` }} /></div></div></div>)}</article>
        <article className="panel transactions"><div className="panel-heading"><div><p className="eyebrow">ACTIVIDAD</p><h2>Movimientos recientes</h2></div><button className="add-button" onClick={() => setModal(true)}>+ Añadir</button></div><div className="filters">{(["Todo", ...categories] as const).map(item => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}</button>)}</div><div className="transaction-list">{visible.map(t => {
          const proof = evidence[t.id];
          const isOpen = selectedEvidence === t.id;
          return <div className="transaction-wrap" key={t.id}><button type="button" className="transaction" aria-expanded={isOpen} onClick={() => setSelectedEvidence(isOpen ? null : t.id)}><span className={`transaction-icon ${t.amount > 0 ? "income" : ""}`}>{icons[t.category]}</span><span className="transaction-info"><b>{t.merchant}</b><small>{formatDay(t.date)} · {t.source}{proof ? " · Ver captura" : " · Registro manual"}</small></span><strong className={t.amount > 0 ? "positive" : "negative"}>{t.amount > 0 ? "+" : "−"}{money.format(Math.abs(t.amount))}</strong><span className="chevron">⌄</span></button>{isOpen && (proof ? <div className="evidence-card"><div className="evidence-copy"><span className="proof-dot" /> <b>COMPROBANTE EXACTO</b><small>{proof.label}</small></div><div className="screenshot-crop"><Image src={`/evidence/transactions/${proof.file}`} alt={`Captura de ${proof.label}`} width={698} height={150} sizes="(max-width: 900px) 100vw, 500px" priority={t.id === "25"} /></div></div> : <div className="manual-proof">Este movimiento fue añadido manualmente y todavía no tiene captura adjunta.</div>)}</div>;
        })}</div></article>
      </section>

      {modal && <div className="modal-backdrop" onMouseDown={() => setModal(false)}><form className="modal" onSubmit={addTransaction} onMouseDown={event => event.stopPropagation()}><button type="button" className="close" onClick={() => setModal(false)}>×</button><p className="eyebrow">NUEVO MOVIMIENTO</p><h2>Registra una transacción</h2><label>Descripción<input autoFocus value={form.merchant} onChange={e => setForm({ ...form, merchant: e.target.value })} placeholder="Ej. Supermercado" /></label><div className="form-grid"><label>Monto<input inputMode="decimal" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="0.00" /></label><label>Fecha<input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></label></div><div className="form-grid"><label>Categoría<select value={form.category} onChange={e => setForm({ ...form, category: e.target.value as Category })}>{categories.map(c => <option key={c}>{c}</option>)}</select></label><label>Cuenta<input value={form.source} onChange={e => setForm({ ...form, source: e.target.value })} /></label></div><button className="save" type="submit">Guardar movimiento</button></form></div>}
    </main>
  );
}
